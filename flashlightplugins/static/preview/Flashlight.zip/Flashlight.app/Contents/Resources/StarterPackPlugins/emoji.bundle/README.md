# Emoji Plugin for [Flashlight](http://flashlight.nateparrott.com/)
To search for emojis, use `emoji {{name}}` or `:{{name}}:`

![ScreenShot](https://raw.github.com/marcbachmann/flashlight-emoji/master/Screenshot.jpg)

